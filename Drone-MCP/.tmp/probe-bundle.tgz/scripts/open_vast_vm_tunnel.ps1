param(
  [Parameter(Mandatory = $true)]
  [string]$Host,

  [Parameter(Mandatory = $true)]
  [int]$Port,

  [string]$User = "root",
  [string]$KeyPath = "$HOME\.ssh\vast_key"
)

ssh `
  -i $KeyPath `
  -o StrictHostKeyChecking=accept-new `
  -N `
  -L 8080:127.0.0.1:8080 `
  -L 6080:127.0.0.1:6080 `
  -L 5900:127.0.0.1:5900 `
  -p $Port `
  "$User@$Host"
