from __future__ import annotations

import sys
import time
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from drone_mcp.sim_runtime import DockerSimulatorRuntime, SimulatorNotReadyError


def main() -> int:
    runtime = DockerSimulatorRuntime(
        ROOT,
        image="drone-mcp/sim-visual:smoke",
        container_name="drone-mcp-sim-visual-smoke",
        dockerfile="docker/sim-visual.Dockerfile",
        headless=False,
        ports=(
            "14540:14540/udp",
            "14550:14550/udp",
            "8888:8888/udp",
            "5900:5900",
            "6080:6080",
        ),
    )
    try:
        print("[1/4] Building visual simulator image...")
        runtime.build_image()
        print("[2/4] Starting visual simulator container...")
        runtime.start()
        print("[3/4] Waiting for simulator readiness...")
        runtime.wait_until_ready(timeout_s=180)
        print("[4/4] Verifying noVNC HTTP surface...")
        deadline = time.time() + 60
        body = ""
        while time.time() < deadline:
            try:
                with urllib.request.urlopen("http://127.0.0.1:6080/vnc.html", timeout=10) as response:
                    body = response.read().decode("utf-8", errors="replace")
                if "noVNC" in body or "vnc" in body.lower():
                    break
            except Exception:
                time.sleep(2)
                continue
            time.sleep(2)
        if "vnc" not in body.lower():
            raise RuntimeError("noVNC page did not become reachable.")
        print("Visual simulator smoke test passed.")
        return 0
    except (SimulatorNotReadyError, RuntimeError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    finally:
        runtime.stop()


if __name__ == "__main__":
    raise SystemExit(main())
