#!/bin/sh
set -eu

REPO_ROOT="${REPO_ROOT:-/opt/drone-mcp}"
OPERATOR_IMAGE="${OPERATOR_IMAGE:-drone-mcp/operator-web:remote}"
OPERATOR_CONTAINER="${OPERATOR_CONTAINER:-drone-mcp-operator-web}"
SIM_CONTAINER="${DRONE_MCP_SIM_CONTAINER:-drone-mcp-sim-visual}"
SIM_IMAGE="${DRONE_MCP_SIM_IMAGE:-drone-mcp/sim-visual:remote}"
SIM_DOCKERFILE="${DRONE_MCP_SIM_DOCKERFILE:-docker/sim-visual.Dockerfile}"
SIM_HEADLESS="${DRONE_MCP_SIM_HEADLESS:-0}"
SIM_PORTS="${DRONE_MCP_SIM_PORTS:-14540:14540/udp,14550:14550/udp,8888:8888/udp,5900:5900,6080:6080}"

cd "$REPO_ROOT"

docker rm -f "$OPERATOR_CONTAINER" >/dev/null 2>&1 || true
docker rm -f "$SIM_CONTAINER" >/dev/null 2>&1 || true

docker build -f docker/operator-web.Dockerfile -t "$OPERATOR_IMAGE" .

set -- \
  docker run -d --restart unless-stopped \
  --name "$OPERATOR_CONTAINER" \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -p 8080:8080 \
  -e "DRONE_MCP_SIM_IMAGE=$SIM_IMAGE" \
  -e "DRONE_MCP_SIM_CONTAINER=$SIM_CONTAINER" \
  -e "DRONE_MCP_SIM_DOCKERFILE=$SIM_DOCKERFILE" \
  -e "DRONE_MCP_SIM_HEADLESS=$SIM_HEADLESS" \
  -e "DRONE_MCP_SIM_PORTS=$SIM_PORTS"

if [ -n "${OPENROUTER_KEY:-}" ]; then
  set -- "$@" -e "OPENROUTER_KEY=$OPENROUTER_KEY"
fi

if [ -n "${OPENROUTER_MODEL:-}" ]; then
  set -- "$@" -e "OPENROUTER_MODEL=$OPENROUTER_MODEL"
fi

set -- "$@" "$OPERATOR_IMAGE"
"$@"

python3 - <<'PY'
import json
import time
import urllib.request

deadline = time.time() + 120
last_error = ""
while time.time() < deadline:
    try:
        with urllib.request.urlopen("http://127.0.0.1:8080/health", timeout=10) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if payload.get("ok"):
            print(json.dumps(payload))
            raise SystemExit(0)
    except Exception as exc:  # pragma: no cover - shell-side health poll
        last_error = str(exc)
        time.sleep(2)

raise SystemExit(f"Operator web did not become healthy: {last_error}")
PY
