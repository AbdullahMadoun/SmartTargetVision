#!/bin/sh
set -eu

export DEBIAN_FRONTEND=noninteractive

if ! command -v docker >/dev/null 2>&1; then
  apt-get update
  apt-get install -y --no-install-recommends docker.io
fi

systemctl enable --now docker
docker version >/dev/null
