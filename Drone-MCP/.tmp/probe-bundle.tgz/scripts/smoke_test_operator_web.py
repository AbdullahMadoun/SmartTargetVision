from __future__ import annotations

import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OPERATOR_IMAGE = "drone-mcp/operator-web:smoke"
OPERATOR_CONTAINER = "drone-mcp-operator-web-smoke"
SIM_CONTAINER = "drone-mcp-sim-visual-web-smoke"


class SmokeError(RuntimeError):
    """Raised when the operator web smoke test fails."""


def run(*args: str, check: bool = True, timeout: int = 600) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        args,
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if check and completed.returncode != 0:
        raise SmokeError(
            f"Command failed: {' '.join(args)}\nSTDOUT:\n{completed.stdout}\nSTDERR:\n{completed.stderr}"
        )
    return completed


def cleanup() -> None:
    run("docker", "rm", "-f", OPERATOR_CONTAINER, check=False, timeout=30)
    run("docker", "rm", "-f", SIM_CONTAINER, check=False, timeout=30)


def http_json(url: str, payload: dict[str, object] | None = None) -> dict[str, object]:
    if payload is None:
        request = urllib.request.Request(url)
    else:
        data = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
    with urllib.request.urlopen(request, timeout=300) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> int:
    cleanup()
    try:
        print("[1/5] Building operator web image...")
        run(
            "docker",
            "build",
            "-f",
            str(ROOT / "docker" / "operator-web.Dockerfile"),
            "-t",
            OPERATOR_IMAGE,
            str(ROOT),
            timeout=1800,
        )
        print("[2/5] Starting operator web container...")
        run(
            "docker",
            "run",
            "-d",
            "--rm",
            "--name",
            OPERATOR_CONTAINER,
            "-v",
            "/var/run/docker.sock:/var/run/docker.sock",
            "-p",
            "18080:8080",
            "-e",
            "DRONE_MCP_SIM_IMAGE=drone-mcp/sim-visual:web-smoke",
            "-e",
            f"DRONE_MCP_SIM_CONTAINER={SIM_CONTAINER}",
            "-e",
            "DRONE_MCP_SIM_DOCKERFILE=docker/sim-visual.Dockerfile",
            "-e",
            "DRONE_MCP_SIM_HEADLESS=0",
            "-e",
            "DRONE_MCP_SIM_PORTS=14540:14540/udp,14550:14550/udp,8888:8888/udp,5900:5900,6080:6080",
            OPERATOR_IMAGE,
            timeout=120,
        )

        print("[3/5] Waiting for operator web health...")
        deadline = time.time() + 60
        while time.time() < deadline:
            try:
                health = http_json("http://127.0.0.1:18080/health")
                if health.get("ok"):
                    break
            except Exception:
                time.sleep(2)
                continue
            time.sleep(2)
        else:
            raise SmokeError("Operator web service did not become healthy.")

        print("[4/5] Starting and checking the visual simulator through the web API...")
        start_result = http_json(
            "http://127.0.0.1:18080/api/tool",
            {"name": "start_simulation", "arguments": {"timeout": "180"}},
        )
        if "Simulation started and is ready" not in start_result["text"]:
            raise SmokeError(f"Unexpected start result:\n{start_result['text']}")

        health_result = http_json("http://127.0.0.1:18080/api/runtime-health")
        if "Ready: yes" not in health_result["text"]:
            raise SmokeError(f"Unexpected runtime health:\n{health_result['text']}")

        print("[5/5] Stopping the visual simulator through the web API...")
        stop_result = http_json(
            "http://127.0.0.1:18080/api/tool",
            {"name": "stop_simulation", "arguments": {}},
        )
        if "Simulation stop command completed" not in stop_result["text"]:
            raise SmokeError(f"Unexpected stop result:\n{stop_result['text']}")

        print("Operator web smoke test passed.")
        return 0
    except SmokeError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    finally:
        cleanup()


if __name__ == "__main__":
    raise SystemExit(main())
