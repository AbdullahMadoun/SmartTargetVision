const chatLog = document.getElementById("chat-log");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const statusBox = document.getElementById("status-box");
const chatState = document.getElementById("chat-state");
const simFrame = document.getElementById("sim-frame");
const openVnc = document.getElementById("open-vnc");

let history = [];

function appendMessage(role, content) {
  const node = document.createElement("div");
  node.className = `chat-entry ${role}`;
  node.textContent = content;
  chatLog.appendChild(node);
  chatLog.scrollTop = chatLog.scrollHeight;
}

async function loadConfig() {
  const response = await fetch("/api/config");
  const data = await response.json();
  simFrame.src = data.vnc_url;
  openVnc.href = data.vnc_url;
  chatState.textContent = data.chat_ready
    ? `Chat ready via ${data.model}`
    : "Chat key not configured";
}

async function refreshStatus() {
  const response = await fetch("/api/runtime-health");
  const data = await response.json();
  statusBox.textContent = data.text;
}

async function callTool(name, argumentsPayload = {}) {
  statusBox.textContent = "Running tool...";
  const response = await fetch("/api/tool", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, arguments: argumentsPayload }),
  });
  const data = await response.json();
  statusBox.textContent = data.text || response.statusText;
}

document.querySelectorAll("[data-tool]").forEach((button) => {
  button.addEventListener("click", async () => {
    const name = button.getAttribute("data-tool");
    const args = name === "get_simulation_logs" ? { lines: "60" } : {};
    await callTool(name, args);
  });
});

chatForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!message) {
    return;
  }
  appendMessage("user", message);
  chatInput.value = "";
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history }),
  });
  if (!response.ok) {
    const error = await response.json();
    appendMessage("assistant", `Error: ${error.detail || response.statusText}`);
    return;
  }
  const data = await response.json();
  history = data.history;
  appendMessage("assistant", data.reply);
  await refreshStatus();
});

loadConfig()
  .then(refreshStatus)
  .catch((error) => {
    statusBox.textContent = `Failed to load UI config: ${error}`;
  });

setInterval(refreshStatus, 10000);
