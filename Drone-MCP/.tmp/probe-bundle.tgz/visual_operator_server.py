#!/usr/bin/env python3

"""HTTP operator surface for remote visual simulation and chat control."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from openai import OpenAI
from pydantic import BaseModel
import uvicorn


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
UI = ROOT / "ui"

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from drone_mcp.operator_chat import LlmResponse, OperatorChatEngine, ToolCall
from drone_mcp.runtime_tool_service import RuntimeToolService


def _read_openrouter_key() -> str:
    return (
        os.environ.get("OPENROUTER_KEY", "").strip()
        or os.environ.get("OpenRouter_Key", "").strip()
        or os.environ.get("OPENROUTER_API_KEY", "").strip()
    )


class ChatRequest(BaseModel):
    message: str
    history: list[dict[str, str]] = []


class ToolRequest(BaseModel):
    name: str
    arguments: dict[str, str] = {}


class OpenRouterClient:
    def __init__(self, api_key: str, model: str) -> None:
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://openrouter.ai/api/v1",
        )
        self.model = model

    def complete(
        self,
        *,
        messages: list[dict[str, object]],
        tools: list[dict[str, object]],
    ) -> LlmResponse:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
        )
        message = response.choices[0].message
        tool_calls = tuple(
            ToolCall(
                id=tool_call.id,
                name=tool_call.function.name,
                arguments=tool_call.function.arguments or "{}",
            )
            for tool_call in (message.tool_calls or [])
        )
        return LlmResponse(
            content=message.content or "",
            tool_calls=tool_calls,
        )


app = FastAPI(title="Drone MCP Operator")
app.mount("/static", StaticFiles(directory=str(UI)), name="static")
tool_service = RuntimeToolService()


@app.get("/health")
def health() -> dict[str, object]:
    return {
        "ok": True,
        "chat_ready": bool(_read_openrouter_key()),
    }


@app.get("/api/config")
def config() -> dict[str, object]:
    return {
        "vnc_url": os.environ.get(
            "OPERATOR_VNC_URL",
            "http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=remote",
        ),
        "model": os.environ.get("OPENROUTER_MODEL", "openai/gpt-4o-mini"),
        "chat_ready": bool(_read_openrouter_key()),
    }


@app.get("/api/runtime-health")
def runtime_health() -> dict[str, str]:
    return {"text": tool_service.get_runtime_health()}


@app.post("/api/tool")
def call_tool(payload: ToolRequest) -> dict[str, str]:
    try:
        result = tool_service.call_tool(payload.name, payload.arguments)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"text": result}


@app.post("/api/chat")
def chat(payload: ChatRequest) -> dict[str, object]:
    api_key = _read_openrouter_key()
    if not api_key:
        raise HTTPException(status_code=400, detail="OpenRouter key is not configured.")
    engine = OperatorChatEngine(
        OpenRouterClient(
            api_key=api_key,
            model=os.environ.get("OPENROUTER_MODEL", "openai/gpt-4o-mini"),
        ),
        tool_service,
    )
    return engine.run_turn(history=payload.history, user_message=payload.message)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(UI / "index.html")


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)
