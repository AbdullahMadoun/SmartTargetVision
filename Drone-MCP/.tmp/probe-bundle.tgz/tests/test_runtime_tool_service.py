from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from drone_mcp.runtime_tool_service import RuntimeToolService
from drone_mcp.sim_runtime import RuntimeStatus, SimulatorNotReadyError


class FakeRuntime:
    def __init__(self, status: RuntimeStatus, logs: str = "", wait_error: Exception | None = None) -> None:
        self._status = status
        self._logs = logs
        self._wait_error = wait_error
        self.calls: list[str] = []

    def ensure_image(self, force_rebuild: bool = False) -> None:
        self.calls.append("ensure_image")

    def start(self) -> None:
        self.calls.append("start")

    def stop(self) -> None:
        self.calls.append("stop")

    def reset(self) -> None:
        self.calls.append("reset")

    def status(self) -> RuntimeStatus:
        self.calls.append("status")
        return self._status

    def wait_until_ready(self, timeout_s: int = 120, poll_interval_s: float = 3.0) -> RuntimeStatus:
        self.calls.append(f"wait_until_ready:{timeout_s}")
        if self._wait_error:
            raise self._wait_error
        return self._status

    def logs_tail(self, lines: int = 200) -> str:
        self.calls.append(f"logs_tail:{lines}")
        return self._logs


class FakeService(RuntimeToolService):
    def __init__(self, runtime: FakeRuntime) -> None:
        self._runtime = runtime

    def runtime(self, image: str = "", container_name: str = "") -> FakeRuntime:
        return self._runtime


class RuntimeToolServiceTest(unittest.TestCase):
    def make_status(self, *, ready: bool = True, running: bool = True) -> RuntimeStatus:
        return RuntimeStatus(
            image="drone-mcp/sim-monocam:test",
            container_name="drone-mcp-test",
            image_present=True,
            running=running,
            ready=ready,
            status_text="Up 18 seconds" if running else "",
            camera_topics=(
                "/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/image",
            )
            if ready
            else (),
            plugin_errors=(),
        )

    def test_start_simulation_formats_success_and_waits(self) -> None:
        runtime = FakeRuntime(self.make_status())
        service = FakeService(runtime)

        result = service.start_simulation(timeout="30")

        self.assertIn("✅ Simulation started and is ready.", result)
        self.assertIn("Ready: yes", result)
        self.assertEqual(runtime.calls, ["ensure_image", "start", "wait_until_ready:30"])

    def test_start_simulation_returns_error_text(self) -> None:
        runtime = FakeRuntime(
            self.make_status(ready=False),
            wait_error=SimulatorNotReadyError("simulator not ready"),
        )
        service = FakeService(runtime)

        result = service.start_simulation(timeout="20")

        self.assertEqual(result, "❌ Error: simulator not ready")

    def test_stop_simulation_reports_state(self) -> None:
        runtime = FakeRuntime(self.make_status(ready=False, running=False))
        service = FakeService(runtime)

        result = service.stop_simulation()

        self.assertIn("✅ Simulation stop command completed.", result)
        self.assertIn("Running: no", result)
        self.assertEqual(runtime.calls, ["stop", "status"])

    def test_get_runtime_health_reports_warning_when_not_ready(self) -> None:
        runtime = FakeRuntime(self.make_status(ready=False))
        service = FakeService(runtime)

        result = service.get_runtime_health()

        self.assertIn("⚠️ Runtime health snapshot.", result)
        self.assertIn("Ready: no", result)

    def test_get_simulation_logs_uses_default_line_count(self) -> None:
        runtime = FakeRuntime(self.make_status(), logs="hello log")
        service = FakeService(runtime)

        result = service.get_simulation_logs()

        self.assertEqual(result, "📁 Simulation logs:\nhello log")
        self.assertEqual(runtime.calls, ["logs_tail:200"])

    def test_invalid_integer_parameter_returns_error(self) -> None:
        runtime = FakeRuntime(self.make_status())
        service = FakeService(runtime)

        result = service.get_simulation_logs(lines="0")

        self.assertEqual(result, "❌ Error: lines must be at least 1.")


if __name__ == "__main__":
    unittest.main()
