from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from drone_mcp.sim_runtime import (
    CAMERA_TOPIC_FRAGMENT,
    CommandResult,
    DockerSimulatorRuntime,
    SimulatorNotReadyError,
)


class StubRunner:
    def __init__(self, responses: list[CommandResult]) -> None:
        self.responses = list(responses)
        self.calls: list[list[str]] = []

    def run(self, args: list[str], *, timeout: int = 600, check: bool = True) -> CommandResult:
        self.calls.append(args)
        if not self.responses:
            raise AssertionError(f"No stubbed response left for command: {args}")
        return self.responses.pop(0)


class SimulatorRuntimeTest(unittest.TestCase):
    def make_runtime(self, runner: StubRunner) -> DockerSimulatorRuntime:
        return DockerSimulatorRuntime(
            ROOT,
            image="drone-mcp/sim-monocam:test",
            container_name="drone-mcp-test",
            runner=runner,
        )

    def test_build_image_and_start_emit_expected_commands(self) -> None:
        runner = StubRunner(
            [
                CommandResult(0, "", ""),
                CommandResult(0, "", ""),
                CommandResult(0, "abc123", ""),
            ]
        )
        runtime = self.make_runtime(runner)

        runtime.build_image()
        runtime.start()

        self.assertEqual(runner.calls[0][:3], ["docker", "build", "-f"])
        self.assertEqual(runner.calls[1], ["docker", "rm", "-f", "drone-mcp-test"])
        self.assertEqual(runner.calls[2][0:4], ["docker", "run", "-d", "--rm"])
        self.assertIn("PX4_SIM_MODEL=gz_x500_mono_cam", runner.calls[2])

    def test_status_is_ready_when_camera_topics_exist_and_logs_are_clean(self) -> None:
        runner = StubRunner(
            [
                CommandResult(0, "[]", ""),
                CommandResult(0, "Up 12 seconds\n", ""),
                CommandResult(0, "", ""),
                CommandResult(
                    0,
                    "\n".join(
                        [
                            "/clock",
                            f"/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/image",
                            f"/world/default/model/x500_mono_cam_0/link/camera_link/sensor/camera/camera_info",
                        ]
                    ),
                    "",
                ),
            ]
        )
        runtime = self.make_runtime(runner)

        status = runtime.status()

        self.assertTrue(status.running)
        self.assertTrue(status.ready)
        self.assertTrue(status.image_present)
        self.assertEqual(len(status.plugin_errors), 0)
        self.assertEqual(len(status.camera_topics), 2)
        self.assertTrue(all(CAMERA_TOPIC_FRAGMENT in topic for topic in status.camera_topics))

    def test_status_detects_plugin_failures(self) -> None:
        runner = StubRunner(
            [
                CommandResult(0, "[]", ""),
                CommandResult(0, "Up 12 seconds\n", ""),
                CommandResult(
                    0,
                    "Error while loading the library [/opt/px4-gazebo/lib/gz/plugins/libGstCameraSystem.so]",
                    "",
                ),
                CommandResult(0, "", ""),
            ]
        )
        runtime = self.make_runtime(runner)

        status = runtime.status()

        self.assertTrue(status.running)
        self.assertFalse(status.ready)
        self.assertTrue(status.image_present)
        self.assertEqual(len(status.plugin_errors), 1)

    def test_status_handles_missing_container(self) -> None:
        runner = StubRunner(
            [
                CommandResult(1, "", "Error: No such image"),
                CommandResult(0, "", ""),
                CommandResult(1, "", "Error: No such container"),
            ]
        )
        runtime = self.make_runtime(runner)

        status = runtime.status()

        self.assertFalse(status.running)
        self.assertFalse(status.ready)
        self.assertFalse(status.image_present)
        self.assertEqual(status.status_text, "")
        self.assertEqual(status.camera_topics, ())

    def test_wait_until_ready_raises_on_plugin_error(self) -> None:
        runner = StubRunner(
            [
                CommandResult(0, "[]", ""),
                CommandResult(0, "Up 12 seconds\n", ""),
                CommandResult(0, "", ""),
                CommandResult(0, "", ""),
                CommandResult(0, "[]", ""),
                CommandResult(0, "Up 12 seconds\n", ""),
                CommandResult(
                    0,
                    "Failed to load system plugin: libGstCameraSystem.so",
                    "",
                ),
                CommandResult(0, "", ""),
            ]
        )
        runtime = self.make_runtime(runner)

        with self.assertRaises(SimulatorNotReadyError):
            runtime.wait_until_ready(timeout_s=1, poll_interval_s=0)

    def test_ensure_image_builds_when_missing(self) -> None:
        runner = StubRunner(
            [
                CommandResult(1, "", "Error: No such image"),
                CommandResult(0, "", ""),
            ]
        )
        runtime = self.make_runtime(runner)

        runtime.ensure_image()

        self.assertEqual(
            runner.calls,
            [
                ["docker", "image", "inspect", "drone-mcp/sim-monocam:test"],
                [
                    "docker",
                    "build",
                    "-f",
                    str(ROOT / "docker" / "sim-monocam.Dockerfile"),
                    "-t",
                    "drone-mcp/sim-monocam:test",
                    str(ROOT),
                ],
            ],
        )

    def test_reset_reuses_start_logic(self) -> None:
        runner = StubRunner(
            [
                CommandResult(0, "", ""),
                CommandResult(0, "abc123", ""),
            ]
        )
        runtime = self.make_runtime(runner)

        runtime.reset()

        self.assertEqual(runner.calls, [
            ["docker", "rm", "-f", "drone-mcp-test"],
            [
                "docker",
                "run",
                "-d",
                "--rm",
                "--name",
                "drone-mcp-test",
                "-e",
                "PX4_SIM_MODEL=gz_x500_mono_cam",
                "-e",
                "HEADLESS=1",
                "-p",
                "14540:14540/udp",
                "-p",
                "14550:14550/udp",
                "-p",
                "8888:8888/udp",
                "drone-mcp/sim-monocam:test",
            ],
        ])


if __name__ == "__main__":
    unittest.main()
