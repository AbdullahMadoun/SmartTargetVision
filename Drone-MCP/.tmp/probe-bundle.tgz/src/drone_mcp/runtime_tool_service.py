from __future__ import annotations

import os
from pathlib import Path

from .sim_runtime import DockerSimulatorRuntime, RuntimeCommandError, SimulatorNotReadyError


def _repo_root() -> Path:
    configured = os.environ.get("DRONE_MCP_REPO_ROOT", "").strip()
    return Path(configured) if configured else Path.cwd()


def _default_image() -> str:
    return os.environ.get("DRONE_MCP_SIM_IMAGE", "drone-mcp/sim-monocam:local").strip()


def _default_container_name() -> str:
    return os.environ.get("DRONE_MCP_SIM_CONTAINER", "drone-mcp-sim-monocam").strip()


def _default_dockerfile() -> str:
    return os.environ.get("DRONE_MCP_SIM_DOCKERFILE", "docker/sim-monocam.Dockerfile").strip()


def _default_ports() -> tuple[str, ...]:
    raw = os.environ.get("DRONE_MCP_SIM_PORTS", "").strip()
    if not raw:
        return (
            "14540:14540/udp",
            "14550:14550/udp",
            "8888:8888/udp",
        )
    return tuple(part.strip() for part in raw.split(",") if part.strip())


def _default_headless() -> bool:
    raw = os.environ.get("DRONE_MCP_SIM_HEADLESS", "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def _parse_int(raw_value: str, *, default: int, minimum: int, field_name: str) -> int:
    candidate = raw_value.strip()
    if not candidate:
        return default
    value = int(candidate)
    if value < minimum:
        raise ValueError(f"{field_name} must be at least {minimum}.")
    return value


class RuntimeToolService:
    TOOL_DEFINITIONS = [
        {
            "type": "function",
            "function": {
                "name": "start_simulation",
                "description": "Start the simulator image and wait until runtime health is ready.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "image": {"type": "string"},
                        "container_name": {"type": "string"},
                        "timeout": {"type": "string"},
                    },
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "stop_simulation",
                "description": "Stop the active simulator container and report the resulting state.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "container_name": {"type": "string"},
                    },
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "reset_simulation",
                "description": "Reset the simulator container and wait until it is healthy again.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "image": {"type": "string"},
                        "container_name": {"type": "string"},
                        "timeout": {"type": "string"},
                    },
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_runtime_health",
                "description": "Return image presence, runtime state, readiness, and camera topic health.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "image": {"type": "string"},
                        "container_name": {"type": "string"},
                    },
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_simulation_logs",
                "description": "Return recent simulator logs from the selected container.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "container_name": {"type": "string"},
                        "lines": {"type": "string"},
                    },
                },
            },
        },
    ]

    def runtime(self, image: str = "", container_name: str = "") -> DockerSimulatorRuntime:
        resolved_image = image.strip() or _default_image()
        resolved_container = container_name.strip() or _default_container_name()
        return DockerSimulatorRuntime(
            _repo_root(),
            image=resolved_image,
            container_name=resolved_container,
            dockerfile=_default_dockerfile(),
            headless=_default_headless(),
            ports=_default_ports(),
        )

    def list_tool_definitions(self) -> list[dict[str, object]]:
        return [tool.copy() for tool in self.TOOL_DEFINITIONS]

    def call_tool(self, name: str, arguments: dict[str, str] | None = None) -> str:
        args = arguments or {}
        if name == "start_simulation":
            return self.start_simulation(
                image=args.get("image", ""),
                container_name=args.get("container_name", ""),
                timeout=args.get("timeout", ""),
            )
        if name == "stop_simulation":
            return self.stop_simulation(container_name=args.get("container_name", ""))
        if name == "reset_simulation":
            return self.reset_simulation(
                image=args.get("image", ""),
                container_name=args.get("container_name", ""),
                timeout=args.get("timeout", ""),
            )
        if name == "get_runtime_health":
            return self.get_runtime_health(
                image=args.get("image", ""),
                container_name=args.get("container_name", ""),
            )
        if name == "get_simulation_logs":
            return self.get_simulation_logs(
                container_name=args.get("container_name", ""),
                lines=args.get("lines", ""),
            )
        raise ValueError(f"Unknown tool: {name}")

    def start_simulation(self, image: str = "", container_name: str = "", timeout: str = "") -> str:
        """Start the verified monocam simulator and wait until it is ready."""
        try:
            timeout_s = _parse_int(timeout, default=120, minimum=1, field_name="timeout")
            runtime = self.runtime(image=image, container_name=container_name)
            runtime.ensure_image()
            runtime.start()
            status = runtime.wait_until_ready(timeout_s=timeout_s)
            return self._format_status("✅ Simulation started and is ready.", status)
        except (RuntimeCommandError, SimulatorNotReadyError, ValueError) as exc:
            return f"❌ Error: {exc}"

    def stop_simulation(self, container_name: str = "") -> str:
        """Stop the simulator container if it is running."""
        try:
            runtime = self.runtime(container_name=container_name)
            runtime.stop()
            status = runtime.status()
            return self._format_status("✅ Simulation stop command completed.", status)
        except (RuntimeCommandError, ValueError) as exc:
            return f"❌ Error: {exc}"

    def reset_simulation(self, image: str = "", container_name: str = "", timeout: str = "") -> str:
        """Reset the simulator container and wait until it is ready again."""
        try:
            timeout_s = _parse_int(timeout, default=120, minimum=1, field_name="timeout")
            runtime = self.runtime(image=image, container_name=container_name)
            runtime.ensure_image()
            runtime.reset()
            status = runtime.wait_until_ready(timeout_s=timeout_s)
            return self._format_status("✅ Simulation reset and is ready.", status)
        except (RuntimeCommandError, SimulatorNotReadyError, ValueError) as exc:
            return f"❌ Error: {exc}"

    def get_runtime_health(self, image: str = "", container_name: str = "") -> str:
        """Return simulator image, container, readiness, and camera topic health."""
        try:
            runtime = self.runtime(image=image, container_name=container_name)
            status = runtime.status()
            prefix = "✅ Runtime health snapshot." if status.ready else "⚠️ Runtime health snapshot."
            return self._format_status(prefix, status)
        except (RuntimeCommandError, ValueError) as exc:
            return f"❌ Error: {exc}"

    def get_simulation_logs(self, container_name: str = "", lines: str = "") -> str:
        """Return recent simulator logs from the active container."""
        try:
            line_count = _parse_int(lines, default=200, minimum=1, field_name="lines")
            runtime = self.runtime(container_name=container_name)
            log_output = runtime.logs_tail(lines=line_count).strip()
            if not log_output:
                log_output = "<no logs available>"
            return f"📁 Simulation logs:\n{log_output}"
        except (RuntimeCommandError, ValueError) as exc:
            return f"❌ Error: {exc}"

    def _format_status(self, heading: str, status) -> str:
        camera_topics = "\n".join(f"- {topic}" for topic in status.camera_topics) or "- <none>"
        plugin_errors = "\n".join(f"- {error}" for error in status.plugin_errors) or "- <none>"
        return (
            f"{heading}\n"
            f"Image: {status.image}\n"
            f"Image Present: {'yes' if status.image_present else 'no'}\n"
            f"Container: {status.container_name}\n"
            f"Running: {'yes' if status.running else 'no'}\n"
            f"Ready: {'yes' if status.ready else 'no'}\n"
            f"Status: {status.status_text or '<not running>'}\n"
            f"Camera Topics:\n{camera_topics}\n"
            f"Plugin Errors:\n{plugin_errors}"
        )
