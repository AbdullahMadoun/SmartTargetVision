#!/usr/bin/env python3

"""Deterministic MCP server for simulator runtime control."""

import logging
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from drone_mcp.runtime_tool_service import RuntimeToolService


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("drone-runtime-mcp")

mcp = FastMCP("drone-runtime")
service = RuntimeToolService()


@mcp.tool()
def start_simulation(image: str = "", container_name: str = "", timeout: str = "") -> str:
    """Start the simulator image and wait until runtime health is ready."""
    logger.info("start_simulation called for image=%s container=%s", image, container_name)
    return service.start_simulation(image=image, container_name=container_name, timeout=timeout)


@mcp.tool()
def stop_simulation(container_name: str = "") -> str:
    """Stop the active simulator container and report the resulting state."""
    logger.info("stop_simulation called for container=%s", container_name)
    return service.stop_simulation(container_name=container_name)


@mcp.tool()
def reset_simulation(image: str = "", container_name: str = "", timeout: str = "") -> str:
    """Reset the simulator container and wait until it is healthy again."""
    logger.info("reset_simulation called for image=%s container=%s", image, container_name)
    return service.reset_simulation(image=image, container_name=container_name, timeout=timeout)


@mcp.tool()
def get_runtime_health(image: str = "", container_name: str = "") -> str:
    """Return image presence, runtime state, readiness, and camera topic health."""
    logger.info("get_runtime_health called for image=%s container=%s", image, container_name)
    return service.get_runtime_health(image=image, container_name=container_name)


@mcp.tool()
def get_simulation_logs(container_name: str = "", lines: str = "") -> str:
    """Return recent simulator logs from the selected container."""
    logger.info("get_simulation_logs called for container=%s lines=%s", container_name, lines)
    return service.get_simulation_logs(container_name=container_name, lines=lines)


if __name__ == "__main__":
    logger.info("Starting drone runtime MCP server...")
    try:
        mcp.run(transport="stdio")
    except Exception as exc:
        logger.error("Server error: %s", exc, exc_info=True)
        sys.exit(1)
